/**
 * Codigo.gs — Recibe respuestas del cuestionario y las guarda en esta Google Sheet.
 *
 * Pégalo en: Google Sheet > Extensiones > Apps Script (reemplaza todo el contenido).
 * Después publícalo como "Aplicación web" (ver README.md).
 *
 * - doPost: agrega UNA fila por participante. Crea los encabezados solo.
 *           Si llega una columna nueva, la agrega al final sin borrar nada.
 *           Ignora envíos repetidos del mismo id_participante.
 * - doGet:  devuelve las respuestas en JSON para resultados.html (pide la clave).
 */

// Cambia esta clave y pon la MISMA en js/config.js (CLAVE_LECTURA).
var CLAVE_LECTURA = 'cambia-esta-clave';

var NOMBRE_HOJA = 'Respuestas';
var MAX_TEXTO = 2000;

function doPost(e) {
  var lock = LockService.getScriptLock();
  try {
    lock.waitLock(20000);
  } catch (err) {
    return json_({ ok: false, error: 'servidor-ocupado' });
  }
  try {
    if (!e || !e.postData || !e.postData.contents) return json_({ ok: false, error: 'sin-datos' });

    var cuerpo = JSON.parse(e.postData.contents);
    var fila = cuerpo && cuerpo.fila;
    if (!fila || typeof fila !== 'object' || !fila.id_participante) {
      return json_({ ok: false, error: 'formato-invalido' });
    }

    var hoja = hoja_();
    var encabezados = asegurarEncabezados_(hoja, Object.keys(fila).concat(['recibido_servidor', 'json_completo']));

    // Evita duplicados (reintentos del mismo dispositivo)
    var colId = encabezados.indexOf('id_participante') + 1;
    var ultima = hoja.getLastRow();
    if (ultima > 1) {
      var ids = hoja.getRange(2, colId, ultima - 1, 1).getValues();
      for (var i = 0; i < ids.length; i++) {
        if (String(ids[i][0]) === String(fila.id_participante)) return json_({ ok: true, duplicado: true });
      }
    }

    var datos = {};
    Object.keys(fila).forEach(function (k) { datos[k] = fila[k]; });
    datos.recibido_servidor = Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyy-MM-dd HH:mm:ss');
    datos.json_completo = JSON.stringify(fila).slice(0, 45000);

    var valores = encabezados.map(function (h) { return limpiar_(datos[h]); });
    var rango = hoja.getRange(hoja.getLastRow() + 1, 1, 1, valores.length);
    rango.setNumberFormat('@'); // todo como texto: evita fechas y fórmulas automáticas
    rango.setValues([valores]);

    return json_({ ok: true });
  } catch (err) {
    return json_({ ok: false, error: 'error-servidor: ' + err.message });
  } finally {
    lock.releaseLock();
  }
}

function doGet(e) {
  var p = (e && e.parameter) || {};
  if (p.accion === 'ping') return json_({ ok: true, mensaje: 'El Apps Script está publicado.' });
  if (p.clave !== CLAVE_LECTURA) return json_({ ok: false, error: 'clave-incorrecta' });

  var hoja = hoja_();
  var ultima = hoja.getLastRow();
  var ultCol = hoja.getLastColumn();
  if (ultima < 2 || ultCol < 1) return json_({ ok: true, filas: [] });

  var valores = hoja.getRange(1, 1, ultima, ultCol).getDisplayValues();
  var enc = valores[0];
  var filas = [];
  for (var i = 1; i < valores.length; i++) {
    var o = {};
    for (var j = 0; j < enc.length; j++) {
      if (enc[j] && enc[j] !== 'json_completo') o[enc[j]] = valores[i][j];
    }
    if (o.id_participante) filas.push(o);
  }
  return json_({ ok: true, filas: filas });
}

/* ---------- Auxiliares ---------- */

function hoja_() {
  var libro = SpreadsheetApp.getActiveSpreadsheet();
  return libro.getSheetByName(NOMBRE_HOJA) || libro.insertSheet(NOMBRE_HOJA);
}

// Crea la fila de encabezados si no existe y agrega al final las columnas nuevas.
function asegurarEncabezados_(hoja, claves) {
  var actuales = [];
  if (hoja.getLastRow() > 0 && hoja.getLastColumn() > 0) {
    actuales = hoja.getRange(1, 1, 1, hoja.getLastColumn()).getValues()[0].map(String);
  }
  var nuevas = claves.filter(function (k) { return actuales.indexOf(k) === -1; });
  if (nuevas.length) {
    var todas = actuales.concat(nuevas);
    hoja.getRange(1, 1, 1, todas.length).setValues([todas]).setFontWeight('bold');
    hoja.setFrozenRows(1);
    return todas;
  }
  return actuales;
}

// Texto seguro: corta lo muy largo y evita que algo como "=..." se vuelva fórmula.
function limpiar_(v) {
  if (v === null || v === undefined) return '';
  var t = String(v).slice(0, MAX_TEXTO);
  if (/^[=+\-@]/.test(t) && isNaN(Number(t))) t = "'" + t;
  return t;
}

function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}

/**
 * Prueba manual desde el editor: selecciona "probarEscritura" y dale Ejecutar.
 * Agrega una fila marcada como PRUEBA. Bórrala después.
 */
function probarEscritura() {
  var r = doPost({ postData: { contents: JSON.stringify({ fila: {
    id_participante: 'PRUEBA-' + new Date().getTime(),
    fecha_hora: 'prueba desde el editor',
    edad: 0
  } }) } });
  Logger.log(r.getContent());
}
